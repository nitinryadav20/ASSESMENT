require('dotenv').config()
const express = require('express')
const bodyParser = require('body-parser')
const https = require('https')


const app = express()
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.json())

app.get('/', (req, res) => {
    res.sendFile(__dirname + "/index.html")
})

app.get('/allmakes', (req, res) => {
    res.sendFile(__dirname + "/allmakes.html")
})

app.post('/allmakes', (req, res) => {
    const manufacturer = req.body.manufacturerName
    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/${manufacturer}?format=json`

    https.get(url, (response) =>{
        const resultData = [];
        response.on('data', function(result){
            resultData.push(result)
        })
        response.on('end', function() {
            let data   = Buffer.concat(resultData);
            let schema = JSON.parse(data);
            res.send(schema.Results)
        });
 
    })

})

app.get('/makeandmodel', (req, res) => {
    res.sendFile(__dirname + "/makeandmodel.html")
})


app.post('/makeandmodel', (req, res) => {
    const vin = req.body.vinNo
    const url = 'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeWMI/1GD?format=json'

    https.get(url, (response) =>{
        const resultData = [];
        response.on('data', function(result){
            resultData.push(result)
        })
        response.on('end', function() {
            let data   = Buffer.concat(resultData);
            let schema = JSON.parse(data);
            res.send(schema.Results)
        });
    })
})


app.get('/allmanufacturers', (req, res) => {
    const url = 'https://vpic.nhtsa.dot.gov/api/vehicles/getallmanufacturers?ManufacturerType=Completed&format=json'

    https.get(url, (response) =>{
        const resultData = [];
        response.on('data', function(result){
            resultData.push(result)
        })
        response.on('end', function() {
            let data   = Buffer.concat(resultData);
            let schema = JSON.parse(data);
            res.send(schema.Results)
        });
 
    })

})


app.listen(process.env.PORT, () => {
    console.log("Server started at port...${process.env.PORT}")
    console.log(`http://localhost:${process.env.PORT}`)
})